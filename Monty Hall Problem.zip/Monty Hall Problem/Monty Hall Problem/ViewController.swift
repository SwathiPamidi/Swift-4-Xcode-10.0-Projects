//
//  ViewController.swift
//  Monty Hall Problem
//
//  Created by Chinna on 9/23/18.
//  Copyright © 2018 Chinna. All rights reserved.
//

import UIKit
import Darwin

class ViewController: UIViewController {
    var winOptionSelected = 0
    var winOptionChanged = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        /*
         var DisclosedChoice = -1
         var changeMind = -1
         
         repeat {
         DisclosedChoice = Int(arc4random_uniform(3))
         } while DisclosedChoice == prizeOption || DisclosedChoice == choosenOption
         
         repeat {
         changeMind = Int(arc4random_uniform(3))
         } while changeMind == DisclosedChoice || changeMind == choosenOption
         */
        
        for i in 0...99{
            
            let prizeOption = Int(arc4random_uniform(3))
            let choosenOption = Int(arc4random_uniform(3))
            if choosenOption == prizeOption {
                winOptionSelected += 1
                //check here how many times original choice wins
            } else {
                winOptionChanged += 1
                //check here how many times changed option wins
            }
        }
        print("In given number of moves \(winOptionSelected) times you win if you stick to your option.")
        print("In given number of moves \(winOptionChanged) times you win if you change your mind in second chance.")
    }


}

